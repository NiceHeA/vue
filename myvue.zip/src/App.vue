<template>
  <div id="app" class="asd">
    <!-- <img src="./assets/logo.png"> --><div id="box">
</div>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
body{
  margin: 0;
  font: 12px "microsoft yahei";

}
a{
  color: #000000;
  text-decoration: none;
}
li{
  list-style-type: none;
}
ul,div,p,img,h2,h3,h5,dl,dt,dd{
  padding: 0;
  margin: 0;
}
</style>
