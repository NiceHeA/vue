import Vue from "vue";
import Vuex from "vuex"

Vue.use(Vuex);

export default new Vuex.Store({
    state:{
        userName:localStorage.getItem("username")||null,
        isLogin:0
    },
    getters:{
        getName(state){
            return state.userName;
        },
        isLogin(state){
            return state.isLogin;
        }
         
    },
    mutations:{
        setstate(state,name){
            state.userName=name;
            state.isLogin=1;
            localStorage.setItem("username",name.toString());
        },
        initstate(state){
            var st=localStorage.getItem("username");
            if(st!=null) state.userName=st;state.isLogin=1;
        },
        removerstate(state){
            state.userName=null;
            state.isLogin=0;
            localStorage.removeItem('username')
        }
    }
})