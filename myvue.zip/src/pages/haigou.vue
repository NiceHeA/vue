<template>
  <div id="hg">
    <div class="hg-box">
      <div class="hg-banner-box">
        <img src="https://kaola-haitao.oss.kaolacdn.com/66389c2b-4c73-48f0-ab01-05838595cf3eT2108251101_1920_400.jpg?x-oss-process=image/resize,w_1920,h_400/quality,q_95/format,webp" >
      </div>
    </div>
    <div class="hg-cont-box">
    
      <div class="hg-contlist">
        <ul>
          <li v-for="(item,index) in list">
            <div class="goods-bd">
              <div class="goods-bd-border">
                <div>
                  <a href="">
                    <img :src="imgurl(index)" alt="">
                  </a>
                </div>
                <div>
                  <h5><a href="">{{item.title}}</a></h5>
                  <div>
                    <p><span>￥{{item.pic}}</span></p>
                    <p><span>￥{{item.picold}}</span></p>
                  </div>
                </div>
                <div><button>立即购买</button></div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      
    </div>

  </div>
</template>

<script>
  export default {
    data(){
      return {
        list:[]
      }
    },
    created(){
      this.$http.get('static/database/haigou.json').then((data) => {
              this.list=data.body.hg
      })
    },
    methods:{
      imgurl(i){
        return require('../assets/'+this.list[i].image);
      }
    }
  }
</script>

<style>
  .hg-box{
    min-width: 1000px;
    margin: 0 auto;
    overflow: hidden;
    text-align: center
  }
  .hg-banner-box{
    height: 400px;
  }
  .hg-cont-box{
    width: 100%;
  }
  .hg-cont-box .hg-contlist{
    width: 1000px;
    margin: 0 auto;
  }
  .hg-cont-box ul li{
    width: 20%;
    height: 320px;
    float: left;
    padding-right: 5px;
    overflow: visible;
    position: relative;
    box-sizing: border-box;
  }
  .hg-cont-box .goods-bd{
    width: 100%;
    height: 100%;
    position: relative;
  }
  .hg-cont-box .goods-bd:hover{
    /* box-sizing: border-box; */
    z-index: 100;
  }
  .hg-cont-box .goods-bd-border{
    border: 1px solid;
    background: #FFF;
    position: relative;
    border-radius: 4px;
    
  }
  .hg-cont-box ul li h5{
    font-size: 18px;
    white-space: nowrap;
    max-height: 25px;
    line-height: 25px;
    overflow: hidden;
    font-weight: 400;
    text-overflow: ellipsis;
    transition: 0.5s ease-out;
  }
  .hg-cont-box .goods-bd-border:hover{
    border: 1px solid #e31436!important;
  }
  .hg-cont-box .goods-bd-border:hover h5{
    max-height: 100px;
    white-space: normal;
    
  }


</style>
