<template>
  <div id="home">
  <top-header></top-header>
  <topMenu></topMenu>
  <div class="topBgWrap">
    <banner></banner>
    <div class="m-floor">
      <div class="m-productfloor" v-for="(dt, _num) in hlist">
        <div class="w-title-line">
            <h2>{{dt.title}}</h2>
            <ul class="w-taglist">
              <li class="first">热搜词：</li>
              <li class="last" v-for="hot in dt.hotTxt">{{hot}}</li>
            </ul>
            <a href="" class="u-btn-more">
              更多好货 >
            </a>
        </div>
        <div class="cont clearfix">
          <div class="partl">
            <a href="">
              <img v-bind:src="dt.partl.imgsrc" >
            </a>
            <ul class="w-secondlist">
              <li v-for="second in dt.partl.secondlist">
                <a href="">{{second.title}}</a>
              </li>
            </ul>
          </div>
          <div class="partm">
            <ul class="w-activlist clearfix">
             <li v-for="partm in dt.partm">
                <a href="">
                  <h3>{{partm.title}}</h3>
                  <p>{{partm.txt}}</p>
                  <img v-bind:src="partm.src" >
                </a>
              </li>

            </ul>
          </div>
          <div class="party m-prolist">
         <head-slide id="sddd" :party='dt.party'></head-slide>
          </div>
        </div>
        <div class="w-logolist clearfix">
          <div class="txt">热卖品牌</div>
          <div class="brandListContainer">
            <a href="" class="pic" v-for="mb in dt.mBottom">
              <img :src="mb.src" >
            </a>

          </div>

        </div>
      </div>
    </div>
    <CommonFooter></CommonFooter>
  </div>

  </div>
</template>



<script>
import TopHeader from  '@/components/common/header';
import topMenu from '@/components/common/topMenu';
import HeadSlide from '@/components/common/slide.vue';
import CommonFooter from '@/components/common/CommonFooter';
import banner from '@/components/common/banner';

export default {
    data(){
      return {
        hlist:[],
        num:0,
        timer:[]
      }
    },
    created(){
      var bbb=localStorage.getItem('username')
      console.log(bbb)
      this.$http.get('static/database/homeList.json').then((data) =>{
         this.hlist=data.body.hlist;
      })
    },
    components:{HeadSlide,topMenu,TopHeader,CommonFooter,banner},
    methods:{

    }
  }

</script>

<style>
  .sliderBox2{
    height: 505px;
    text-align: center;
  }
  .topBgWrap{
    min-height: 505px;
    background: #f3f3f3;
  }

  .m-floor{
    background-color: rgb(246, 246, 246);
  }
  .clearfix:after{
    visibility: hidden;
    display: block;
    font-size: 0;
    content: " ";
    clear: both;
    height: 0;
  }
  .m-productfloor{
    margin: 0 auto;
    width: 1100px;
  }
  .w-title-line{
    position: relative;
    height: 74px;
    padding-top: 25px;
    border-top: 1px solid #e9e9e9;
    margin: 0;
    box-sizing: border-box;
  }
  .m-productfloor .w-title-line   h2{
    margin-right: 20px;
    float: left;
    font-size: 22px;
    color: #333;
  }
  .w-taglist{
    font-size: 14px;
    color: #999;
    line-height: 32px;
    float: left;
  }
  .w-taglist li{
    position: relative;
    top: 3px;
    float: left;
    margin-right: 14px;
  }
  .u-btn-more{
    position: absolute;
    right: 0;
    top: 24px;
    font-size: 14px;
    color: #999;
  }
  .m-productfloor .cont{
    background-color: #FFFFFF;
  }
  .m-productfloor .partl, .m-productfloor .partm{
    float: left;
    position: relative;
  }
  .m-productfloor .partl img{
    height: 541px;
    display: block;
  }
  .w-secondlist{
    position: absolute;
    left: 24px;
    bottom: 24px;
  }
  .w-secondlist li{
    float: left;
    margin: 0 18px 8px 0;

  }
  .w-secondlist li,.w-secondlist li a{
    width: 82px;
    height: 42px;
  }
  .w-secondlist li a{
    display: block;
    height: 18px;
    padding: 11px 0;
    font-size: 12px;
    color: #333;
    border-radius: 40px;
    background: #fff;
    border: 1px solid #eee;
    width: 80px;
    box-shadow: 0 0 0 1px rgb(0 0 0 / 10%);
    text-align: center;
  }
  .m-productfloor .partm{
    width: 550px;
    border-top:1px solid #e9e9e9;
  }
  .w-activlist li{
    width: 274px;
    height: 269px;
    float: left;
    text-align: center;
    border: 1px solid #e9e9e9;
    border-width: 0 1px 1px 0;
  }
  .w-activlist li a{
    width: 274px;
    display: block;
    padding: 30px 0 0;
    height: 200px;
    color: #333;
  }
  .w-activlist h3,.w-activlist p{
    white-space: normal;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .w-activlist h3{
    font-size: 24px;
    font-weight: 400;
    line-height: 1;
    margin: 0 10px;
  }
  .w-activlist p{
    font-size: 14px;
    line-height: 20px;
    margin: 10px 10px 14px;
    color: #666;
  }


  .w-logolist{
    margin: 20px 0 40px;
    border: 1px solid #eaeaea;
    line-height: 167px;
    background: #fff;
  }
  .w-logolist .txt{
    font-size: 16px;
    color: #000;
    font-weight: 700;
    text-indent: 20px;
    line-height: 48px;
    height: 48px;
    text-align:left;
    border-bottom: 1px solid #eaeaea;
  }
  .w-logolist .brandListContainer{
    margin-right: -1px;
    width: 1111px;
  }
  .w-logolist .pic:first-child{
    border-left: 0;
  }
  .w-logolist .pic{
    display: inline-block;
    position: relative;
    float: left;
    width: 219px;
    height: 167px;
    zoom: 1;
    border-left: 1px solid #e9e9e9;
    text-align: center;
  }
  .w-logolist .pic img{
    width: 120px;
    height: 120px;
    vertical-align: middle;
    display: inline-block;
  }
</style>
