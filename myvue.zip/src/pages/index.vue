<template>
  <div id="">
    
  </div>
</template>

<script>
import TopHeader from  '@/components/common/header'
import topMenu from '@/components/common/topMenu'
import HeadSlide from '@/components/common/slide.vue'
export default {
    data(){
      return {
        hlist:[],
        num:0,
        timer:[]
      }
    },
    created(){
      this.$http.get('static/database/homeList.json').then((data) =>{
         this.hlist=data.body.hlist;
      })
    },
    components:{HeadSlide,topMenu,TopHeader},
    methods:{

    }
  }

</script>

<style>
</style>
