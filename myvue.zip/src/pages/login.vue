<template>
  <div id="lg">
      <div class="lg-box">
          <div class="lg-header">
              <div class="lg-headerWrap">
                  <img src="../assets/loginTop.png" alt="">
              </div>
          </div>
          <div class="lg-cont">
              <div class="lg-contBody">
                <img class="default-img" src="https://kaola-haitao.oss.kaolacdn.com/e2722b45-286b-45e9-a8e2-4558f4f1bee6.png" alt="">
                <div class="mini-lgBody">
                    <div id="login">
                        <p class="title">手机号登录</p>
                        <div class="login-cont">
                            <p class="lg-tips">{{tip}}</p>
                            <div><input id="loginId" type="text" placeholder="请输入手机号码" v-model="val" @keyup="check"></div>
                            <div><input id="loginCode" type="text" placeholder="请输入验证码" v-model="sCode"></div>
                            <div class="lg-codeTip">
                                <p><a href="javascript:void(0);" @click="code">{{codeTime}}</a></p>
                            </div>
                            <div><button class="lg-button" @click="subm">登录</button></div>
                        </div>
                    </div>
                </div>
              </div>
          </div>
          <div>
              <img src="../assets/login-foot.png" alt="">
          </div>
      </div>
  </div>
</template>

<script>
  export default {
      data(){
          return{
            val:"",
            tip:"",
            sCode:"",
            sTime:'',
            codeTime:"获取验证码",
            staus:false,
            codeSta:false
          }
      },
      mounted(){
          
         
      },
      methods:{
          subm(){
               
                
              if(this.staus&&this.sCode==123456&&this.codeSta){
                  this.tip="登录成功"
                  this.$store.commit('setstate',this.val)
                //   this.Aglobal.setCooki(this.val);
                //   this.Aglobal.getCooki();
                  this.$router.push('/');
                //   this.$store.commit()
              }else if(this.staus&&!this.codeSta){
                  this.tip="请先获取验证码"
              }else if(this.staus&&this.sCode!=123456){
                  this.tip="验证码错误"
              }else{
                  this.tip="手机号码格式错误"
              }
          },
          check:function(){
              let reg = /^1[3|4|5|7|8][0-9]{9}$/;
              let sta = reg.test(this.val);
              this.staus=sta?true:false
          },
          code(){
              if(this.staus&&!this.codeSta){
                 window.alert("验证码是123456");
                 this.tip="";
                this.codeSta=true;
                 this.setTime();
              }else{
                  this.tip="手机号码格式错误"
              }
          },
          setTime(){
               var _this=this
               var s=60;
             _this.sTime=setInterval(function(){
                 if(s==0){
                    _this.clearTimeSet();
                    _this.codeTime="重新获取验证码";
                 }else{
                    s--;
                    _this.codeTime=s+"秒后重新获取验证码";
                 }
               
             },100);
          },
          clearTimeSet(){
            clearInterval(this.sTime);
          }
         
      },
      beforeDestroy(){
          this.clearTimeSet
      }
  
  }
</script>

<style>
 .lg-box{
     width: 100%;
 }
 .lg-header{
     width: 100%;
     height: 100px;
     background: #FFF;
     border-bottom: 1px solid #e8e8ea;
 }
 .lg-headerWrap{
     width: 1000px;
     margin: 0 auto;
 }
 .lg-cont{
     width: 100%;
     background-color: #f8f8f8;
 }
 .lg-cont .lg-contBody{
     width: 1000px;
     height: 600px;
     margin: 0 auto;
     position: relative;
 }
 .lg-cont .lg-contBody .default-img{
     position: absolute;
     left: 10px;
     top: 50%;
     margin-top: -101px;
     width: 400px;
     height: 203px;
 }
 .mini-lgBody{
     position: absolute;
     right: 0;
     top: 15%;
     width: 350px;
     height: 300px;
     background: #FFF;
     border: solid 1px #eaeaea;
 }
 #login .login-cont{
     padding:  0 40px;
 }
 /* #login .login-cont .lg-tips{

 } */
 #login .title{
     padding: 30px 0 20px 0;
     font-size: 15px;
     font-weight: 800;
 }
 #loginId,#loginCode{
     width: 80%;
     height: 30px;
     text-indent: 15px;
     line-height: 30px;
     border: 1px solid #d5d5d5;
     margin-bottom: 15px;
     border-radius: 8px;    
 }
  #login .lg-button{
      width: 100px;
      height: 30px;
      line-height: 25px;
      margin-top: 15px;
      border: 1px;
      border-radius: 5px;
      background: #e24141;
      color: #fff;
  }
  #login .lg-button:hover{
      background: #d43c3c;
  }
  #login .lg-codeTip p{
      text-align: right;
      padding-right: 23px;
  }
  #login .lg-codeTip p a:hover{
      color: indianred;
  }
</style>
