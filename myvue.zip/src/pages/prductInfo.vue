<template>
  <div id="productInfo">
      <TopHeader></TopHeader>
      <topMenu></topMenu>
      <div class="zzc" v-if="cityS" @click="cityS=false"></div>
      <div class="mainWrap">
          <div class="product-box clearfix">
              <div class="PImg">
                  <div id="showImg" v-on:mousemove="onMove($event)" v-on:mouseleave="onOut()">
                      <img id="imgIn" :src="sImg" alt="">
                      <b class="shadow" v-bind:style="{'left':pos.left+'px','top':pos.top+'px'}"></b>
                      
                  </div>
                  <div id="showDetails" v-if='iShow'>
                        <img id="showimgBig" :src="sImg" alt="" v-bind:style="{'left':'-'+pos.left*2+'px','top':'-'+pos.top*2+'px'}" >
                  </div>
                  <div class="litimg_box">
                      <ul>
                          <li v-for="(item,index) in imgList" v-bind:class='{"clas1":index==imgPage}'><a v-on:click="imgCut(index)"><img :src="imgUrl(index)" alt=""></a></li>
                      </ul>
                  </div>
              </div>
              <dl class="pinfo">
                <dt class="product-title">
                  <span >【李冰冰同款冰袖】VVC韩国冰丝女神防晒袖套男女薄长款开车冰丝袖子手臂套 均码</span>
                </dt>
                <dt class="subTit">
                  采用先进的光学布，利用光源转换技术把太阳为有益的光波，达到美肤功效。产品上市以来，就得到了大量明星的青睐与推崇。
                </dt>
                <dd class="m-price-wrap">
                  <div class="m-price">
                    <span style="margin:16px 0 15px 10px;display: inline-block;float:left;font-size:13px;color: #666;">售价</span>
                    <div style="margin:11px 0 10px 80px">
                      <span class="currentPrice">$38</span>
                      <span class="m-memberLabel">包邮</span>
                    </div>
                  </div>
                </dd>
                <dd class="postage clearfix">
                  <span class="m-line-title">运费</span>
                  <span>
                    <span>北京</span>
                    <span>至</span>
                    <div class="m-addrw">
                      
                      <div class="m-addr">
                        <div class="iptw" v-on:click.stop="cityShow()">
                          <span class="iptmsg">
                            <span v-for="s in cityT">{{s.name}}</span>
                          </span>
                          <span>∨</span>
                        </div>
                        <div class="box" v-if="cityS">
                          <div class="tt">
                            <ul class="ttw">
                              <li v-for="(item,n) in cityT" v-bind:class='[cityAc==n?"tli act":"tli"]' v-on:click="cityAcClick(n)">{{item.tt}}</li>
                            </ul>
                          </div>
                          <div class="boxlist clearfix">
                            <ul>
                              <li v-for="(c,i) in cityL"> <a v-on:click="cityList(i,c.name)" v-bind:class='[i==cityT[cityAc].active?"av":""]'>{{c.name}}</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                     
                    </div>
                  </span>
                </dd>
                <dd  class="postage clearfix infoColor" >
                  <span class="m-line-title">颜色</span>
                  <div class="nColor">
                    <ul>
                      <li><img src="../assets/product1.jpg" alt=""></li>
                      <li><img src="../assets/product2.jpg" alt=""></li>
                      <li><img src="../assets/product3.jpg" alt=""></li>

                    </ul>
                  </div>
                </dd>
                <dd  class="postage clearfix chima_box">
                  <span class="m-line-title">尺码</span>
                  <div class="chimaC">
                    <ul class="clearfix">
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                      <li>31</li>
                    </ul>
                  </div>
                </dd>
                <dd  class="postage clearfix chima_box">
                  <span class="m-line-title">数量</span>
                  <div class="inNum">
                    <a href="">-</a>
                    <input type="text" value="1">
                    <a href="">+</a>
                  </div>
                </dd>
                <dd class="subm">
                  <button>立即购买</button>
                </dd>
              </dl>
          </div>
      </div>
      <CommonFooter></CommonFooter>
  </div>
</template>

<script>
import TopHeader from  '@/components/common/header';
import topMenu from '@/components/common/topMenu';
import CommonFooter from '@/components/common/CommonFooter';
  export default {
      data(){
          return {
              pos:{
                  top:0,
                  left:0
              },
              iShow:false,
              imgList:[],
              sImg:"",
              imgPage:0,
              cityL:[],
              cityS:false,
              cityT:[
                {tt:"省份",dt:[],active:0,name:"北京"}
                ],
              cityAc:0
          }
      },
      created(){
         this.$http.get('static/database/cityList.json').then((data) => {
           this.cityT[0].dt=data.body.cityList;
            this.cityL=this.cityT[0].dt;
           this.cityAc=0;
      })
        var l = [ "product1.jpg",
                  "product2.jpg",
                  "product3.jpg",
                  "product4.jpg",]
            this.imgList=l;
            this.sImg=require('../assets/'+this.imgList[0])
            
      },
      components:{TopHeader,topMenu,CommonFooter},
      methods:{
        onMove($event){
               this.iShow = true;
               this.pos.left=$event.offsetX-100;
                  this.pos.top=$event.offsetY-100;
              if($event.offsetX<100){
                  this.pos.left=0
              }else if($event.offsetX>300){
                  this.pos.left=200;
              }
              if($event.offsetY<100){
                  this.pos.top=0;
              }else if($event.offsetY>300){
                  this.pos.top=200;
              }
                 
              
        },
        onOut(){
          this.iShow = false;
        },
        imgUrl(i){
          return require('../assets/'+this.imgList[i])
        },
        imgCut(i){
          this.sImg=require('../assets/'+this.imgList[i])
          this.imgPage = i;
        },
        cityList(i,s){
          this.$set(this.cityT,this.cityAc,{
            tt:this.cityT[this.cityAc].tt,
            dt:this.cityT[this.cityAc].dt,
            active:i,name:s});
            
          if(this.cityAc==0){
            this.cityT.splice(1,2);
            if(this.cityL[i].city.length>1){
              this.cityT[1]={tt:"城市",dt: this.cityL[i].city}
              this.cityL=this.cityL[i].city
              this.cityAc=1;
            }else if(this.cityL[i].city!=""){
              this.$set(this.cityT,1,{tt:"县/区",dt: this.cityL[i].city[0].area})
              this.cityL=this.cityT[1].dt
              this.cityAc=1;
            }else{
              this.cityAc=0;
            }
          }else if(this.cityAc==1){
            
            if(this.cityT[1].dt[i].area){
              this.cityT[2]={tt:"县/区",dt:this.cityT[1].dt[i].area,name:"",active:0}
              this.cityL=this.cityL[i].area
              this.cityAc=2;
            }else{
               this.cityAc=1;
            }
            
          }else if(this.cityAc==2){
                     this.cityAcClick(2)  
          }
           
        },
        cityShow(){
          this.cityS=true
        },
        cityAcClick(n){
          this.cityAc=n
          this.cityL=this.cityT[n].dt
        }
      }
  }
</script>

<style>
.mainWrap{
    width: 1090px;
    margin: 0 auto;
}
.product-box{
    margin: 20px 0 0;
    position: relative;
}
.product-box .PImg{
    float: left;
    width: 402px;
    height: 488px;
    position: relative;
    display: inline;
    z-index: 10;
}
.clearfix:after{
  visibility: hidden;
  display: block;
  font-size: 0;
  content: " ";
  clear: both;
  height: 0;
}
#showImg{
  position: relative;
  top: 0;
  left: 0;
  border: 1px solid #eee;
  width: 400px;
  height: 400px;
  overflow: hidden;
  cursor: crosshair;
}
#showImg img{
  width: 400px;
  height: 400px
}
#showImg .shadow{
  width: 200px;
  height: 200px;
  background-color: #000;
  opacity: 0.3;
  position:absolute;
  top:0;
  left: 0;
  display: none;
  pointer-events: none;
}
#showImg:hover .shadow{
  display: inline-block;
}
#showimgBig{
  position: absolute;
}
#showDetails{
  position: absolute;
  left: 425px;
  top: 0;
  width: 400px;
  height: 400px;
  overflow: hidden;
}
.litimg_box{
  position: absolute;
  overflow: hidden;
  top: 410px;
  left: 35px;
  width: 330px;
}
.litimg_box li{
  width: 70px;
  height: 70px;
  overflow: hidden;
  float: left;
  margin-right: 10px;
  border:1px solid #d7d7d7;
}
.litimg_box li a img{
  width: 64px;
}
.litimg_box .clas1{
  border: 1px solid red;
}
.pinfo{
  position: relative;
  float: left;
  width: 658px;
  margin-left: 30px;
  font-size: 12px;
  z-index: 9;
}
.pinfo .product-title{
  margin-top: 10px;
  margin-bottom: 5px;
  font-weight: 600;
  font-size: 18px;
  line-height: 26px;
}
.pinfo .subTit{
  margin-bottom: 11px;
  color: #333;
  line-height: 20px;
  font-size: 13px;
}
.pinfo .m-price-wrap{
  background-color: #f9f9f9;
  z-index: 22;
  margin-bottom: 12px;
  border-bottom: 1px dotted #ddd;
  padding-bottom: 4px;
}
.pinfo .m-price-wrap .m-price{
  overflow: hidden;
  position: relative;
  padding-top: 5px;
  border-top: 1px dotted #ddd;
  z-index: 100;
}
.pinfo .currentPrice{
  font-size: 26px;
  color: #e31436;
  font-weight: bold;
}
.pinfo .m-memberLabel{
  display: inline-block;
  margin-left: 5px;
  background-color: #f68587;
  height: 18px;
  line-height: 18px;
  padding: 0 5px;
  color: #fff;
  font-size: 12px;
  vertical-align: 5px;
  border-radius: 2px;
}
.pinfo .postage{
  position: relative;
}
.m-line-title{
  float: left;
  line-height: 24px;    
  margin-left: 10px;
  font-size: 12px;
  display: inline-block;
  width: 70px;
  color: #666;
  vertical-align: middle;
}
.m-addrw{
  display: inline-block;
  font-size: 0;
  vertical-align: middle;
  margin-right: 20px;
}
.zzc{
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
  z-index: 9;
}
.m-addr{
  position: relative;
  display: inline-block;
  height: 20px;
  line-height: 20px;
}
.m-addr .iptw{
  position: relative;
  display: inline-block;
  height: 22px;
  line-height: 22px;
  width: auto;
  padding: 0 5px;
  vertical-align: middle;
  text-align: left;
  border: 1px solid #ccc;
  cursor: pointer;
  font-size: 12px;
  margin-top: -2px;
  margin-left: 5px;
}
.m-addr .iptmsg, .m-addr .iptdown{
  display: inline-block;
  height: 18px;
  line-height: 18px;
  vertical-align: top;
}
.m-addr .iptmsg{
  width: 180px;
  white-space: nowrap;
  overflow: hidden;
  margin-top: 2px;

}
.m-addr .box{
  position: absolute;
  left: 0;
  top: 19px;
  padding: 10px 0;
  min-width: 350px;
  color: #000;
  border: #ddd solid 1px;
  background-color: #fff;
  z-index: 8888;
  box-shadow: 0 1px 2px 0 rgb(0 0 0 / 15%);
  font-size: 12px;
}
.m-addr .box .tt{
  height: 30px;
  width: 100%;
  padding-left: 10px;
  overflow: hidden;
}
.m-addr .box .ttw{
  border-bottom: 1px solid #ddd;
  height: 29px;
  width: 420px;
}
.m-addr .box .tli{
  position: relative;
  float: left;
  width: auto;
  min-width: 58px;
  line-height: 32px;
  height: 28px;
  padding: 0 5px;
  margin-right: -1px;
  text-align: center;
  border: 1px solid #ddd;
  cursor: pointer;
  background: #fff;
}
.m-addr .box .tli.act{
  font-weight: bold;
  height: 29px;
  border-bottom: none;
}
.m-addr .box .tli.act:before{
  position: absolute;
  left: -1px;
  top: -1px;
  width: 100%;
  border-top: 2px solid #d21c44;
  border-left: 1px solid #d21c44;
  border-right: 1px solid #d21c44;
  content: "";
  z-index: 2;
}
.m-addr .boxlist{
  float: left;
  width: 420px;
  padding: 0 20px;
  overflow: hidden;
}
.m-addr .boxlist li{
  margin-top: 5px ;
  float: left;
  width: 25%;
}
.m-addr .boxlist a{
  display: inline-block;
  line-height: 24px;
  height: 24px;
  padding: 0 5px;
  white-space: nowrap;
  word-break: keep-all;
  color: #000;
  outline: none;
  cursor:pointer
}
.m-addr .boxlist a:hover {
  line-height: 22px;
  height: 22px;
  padding: 0 4px;
  color: #e31436;
  border: 1px solid #e31436;
  text-decoration: none;
  cursor: pointer;
}
.m-addr .boxlist a.av{
  line-height: 22px;
  height: 22px;
  padding: 0 4px;
  color: #e31436;
  border: 1px solid #e31436;
  text-decoration: none;
  cursor: pointer;
}
.nColor li img{
  width: 50px;
  height: 50px;
}
.nColor li{
  float: left;
  margin-right: 10px;
  border: 1px solid #ccc;
}
.infoColor{
  padding-top: 15px;
}
.infoColor .m-line-title{
  height: 58px;
  line-height: 58px;
}
.nColor li:hover{
  border-color: #d41c44;
}
.chima_box{
  padding-top: 15px;
}
.chima_box ul li{
  float: left;
  margin-right: 10px;
  border: 1px solid #ccc;
  text-align: center;
  padding: 5px 15px;
  margin-top: 5px;
}
.chima_box ul li:hover{
  border-color: #d41c44;
  cursor: pointer;
}
.chima_box .chimaC{
  float: left;
  width: 480px;
}
.inNum a{
  float: left;
  display: inline-block;
  width: 22px;
  height: 22px;
  line-height: 22px;
  text-align: center;
  border: 1px solid #CCC;
}
.inNum input{
  float: left;
  width: 38px;
  border: 1px solid #CCC;
  height: 24.1px;
  text-align: center;
}
.subm{
  margin-top: 20px;
  text-align: center;
}
.subm button{
  width: 165px;
  height: 50px;
  border: 2px solid #d41c44;
  background-color: #ffeced;
  color: #d31b44;
  line-height: 46px;
  display: inline-block;
  margin-right: 20px;
  text-align: center;
  font-size: 18px;
  font-weight: bold;
  text-decoration: none;
  vertical-align: middle;
}
.subm button:hover{
  color: #f8305b;
  border-color: #f8305b;
  background-color: #fffaf8;
}
</style>
