<template>
  <div>
    <div id="topTabBox">
      <div id="topTab">
        <div id="topCats" class="navitm-cats">
          <div class="toplevel">
            <div class="lineicon">
              <i></i>
              <i></i>
              <i></i>
            </div>
            <span>所有分类</span>
          </div>
          <ul class="catitmlst">
            <!--  <-->
            <li v-for="(lst,index) in ctgList"  v-on:mousemove="hoverAddClass($event)" @mouseleave="hoverRemoveClass($event)">
              <img class="icon" v-bind:src="lst.ctgImg1" >
              <img class="icon iconhv" v-bind:src="lst.ctgImg2" >
              <span>{{lst.ctgName}}</span>
              <div class="m-ctgcard">
                <div class="m-ctglist">
                  <div class="m-ctgtbl clearfix">

                      <div class="litd" v-for=" (two,ii) in lst.ctgTab" :name="ii+1">
                        <div class="underTitleMiddleLine"></div>
                        <div class="item">
                          <p class="title">
                            <a href="" class="cat2">{{two.tabName}} </a>
                          </p>
                          <div class="ctgnamebox" >
                            <a href="" v-for="(item,i) in two.ctglist">{{item}}</a>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <ul id="funcTab">
          <li>
            <a href="" style="color: #ff1e32;">首页</a>
          </li>
          <li>
            <router-link to='/haigou'>
              <a href="">海外直购</a>
            </router-link>
          </li>
          <li>
             <router-link to='/haigou'>
              <a href="">海购出品</a>
            </router-link>
          </li>
          <li>
             <router-link to='/haigou'>
              <a href="">品质奶粉</a>
            </router-link>
          </li>
          <li>
             <router-link to='/haigou'>
              <a href="">人气面膜</a>
            </router-link>
          </li>
          <li>
             <router-link to='/haigou'>
              <a href="">充值</a>
            </router-link>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        ctgList:[]
      }
    },
    created(){
      this.$http.get('static/database/headerMenu.json').then((data) => {
        this.ctgList = data.body.menuList
      })
    },
    methods:{
      hoverAddClass:function($event){
        $event.currentTarget.className="t-hover";
      },
      hoverRemoveClass:function($event){
        $event.currentTarget.className=""
      }
    }
  }

</script>

<style>
  #topTabBox{
    border-bottom: 1px solid #ccc;
    background: #fff;
  }
  #topTab{
    position: relative;
    height: 40px;
    width: 1090px;
    margin: 0 auto;
    line-height: 40px;
    z-index: 100;
  }
 .navitm-cats{
    float: left;
    height: 40px;
    width: 164px;
   background: linear-gradient(
   90deg,red,#ff3264);
   color: #fff;
   font-size: 14px;
   text-align: center;
   padding-left: 0;
   overflow:hidden;  
  }
  .navitm-cats:hover{
   overflow:visible;
  }
  .navitm-cats .toplevel{
    display: inline-block;
    height: 40px;
    line-height: 40px;
    width: 164px;
    text-align: left;
    border-bottom: 1px solid #ff5160;
  }
  .navitm-cats .lineicon{
    display: inline-block;
    width: 15px;
    height: 12px;
    margin: 0 24px 0 15px;
  }
  .navitm-cats .lineicon i{
    width: 15px;
    height: 0;
    border-top: 2px solid #ddd;
    display: block;
    margin-bottom: 3px;
  }
  .navitm-cats .catitmlst{
    background: linear-gradient(
    90deg,red,#ff3264);
    padding-bottom: 0.5px;
  }
  .navitm-cats .catitmlst li{
    padding-left: 9px;
    width: 151px;
    cursor: pointer;
    text-align: left;
    height: 37.3px;
    line-height: 38px;
    margin-left: 2px;
    border-bottom: 1px solid #ff5160;
  }
 .navitm-cats .catitmlst li.t-hover .m-ctgcard{
    display: block;
  }
  .navitm-cats .catitmlst li .iconhv{
    display: none;
  }
 .navitm-cats .catitmlst li:hover .icon{
    display: none;
  }
  .navitm-cats .catitmlst li:hover{
    background: #FFFFFF;
    color: #ff3264;
    background: #FFFFFF;
    border-right: 3px solid #ff3263;
  }
  .navitm-cats .catitmlst li:hover .iconhv{
    display: inline-block;
  }
  .navitm-cats .catitmlst .icon{
    width: 20px;
    height: 20px;
    vertical-align: middle;
    padding: 0 20px 0 4px;
  }
  .navitm-cats .m-ctgcard{
    transition: height .4s;
    position: absolute;

    top: 40px;
    left: 164px;
    width: 930px;
    /* overflow: auto; */
    max-height: 459px;
    height: 459px;
    background: #fff;
    border: 1px solid #ff1a33;
    border-left-width: 0;
    text-align: left;
    color: #333;
    cursor: auto;
    display: none;
  }
  .navitm-cats .m-ctgtbl .litd{
    float: left;
    width: 50%;
    vertical-align: top;
    position: relative;
  }
  .navitm-cats .m-ctglist{
    margin: 0 20px 20px 15px;
    width: 658px;
    max-height: 440px;
    height: 440px;
    overflow: hidden;
  }
  .navitm-cats .m-ctglist .underTitleMiddleLine{
    height: 1px;
    width: 642px;
    background: #eaeaea;
    position: absolute;
    top: 34px;
  }
  .navitm-cats .m-ctglist .item .title{
    height: 34px;
    line-height: 34px;
    font-size: 14px;
    font-weight: 700;
  }
  .navitm-cats .m-ctglist a.cat2{
    display: inline;
    color: #333;
    text-align: left;
  }
  .navitm-cats .m-ctglist .ctgnamebox{
    margin-left: -8px;
    font-size: 0;
  }
  .navitm-cats .m-ctglist .ctgnamebox a{
    display: inline-block;
    height: 14px;
    line-height: 14px;
    padding: 0 10px;
    margin-top: 20px;
    font-size: 13px;
    color: #666;
  }
  #funcTab li{
    float: left;
    height: 40px;
    overflow: hidden;
    padding: 0 20px;
  }
  #funcTab li a{
    color: #333;
    display: block;
    text-align: center;
    font-size: 15px;
    font-weight: 700;
  }

</style>
