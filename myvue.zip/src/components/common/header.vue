<template>
  <div id="doc">
    <div id="topNav">
      <div id="topNavWrap">
        <div id="topNavLeft">
          <span>欢迎你!</span>
          <div style="float:left">
            <router-link to='/login'>
              <a class="login" href="">手机用户{{this.$store.getters.getName}}</a>
            </router-link>
            <span class="sep"></span>
            <router-link to='/login'>
              <a  href="">免费注册</a>
            </router-link>
           </div>
        </div>
        <ul id="topNavRight">
          <li v-for=" index in connt ">
            <a v-if="index.list =='null'" href="" class="toplevel">{{index.title}}</a>
            <div class="mcDropMenuBox" v-else>
              <a href="" class="toplevel topNavHolder">{{index.title}}</a>
              <div class="mcDropMenu">
                  <a v-for="ii in index.list "  v-bind:href="ii.url" >{{ii.name}}</a>

              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div id="docHead" :class="{'topTabBoxFixed':iFixe}">
      <div id="docHeadWrap">
        <a href="" class="logo_new">
        </a>
        <div class="m-searchiptbox">
          <div id="topsearchbox">
            <div id="topsearch">
              <div class="wrap">
                <input type="" name="" id="topSearchInput" value="" />
              </div>
              <span class="topsearchboxBackGround">
                <span id="topSearchBtn" class="w-icon"></span>
              </span>

              <span class="w-icon w-icon-Sc1"></span>
            </div>
          </div>
          <ul>
          </ul>
        </div>
        <a href="" class="m-shopcartnew">
          <i class="shop-cart-icon"></i>
          <span class="wrap">购物车</span>
        </a>
      </div>
    </div>
  </div>

</template>
<script>
  export default {

    data(){
      return {
        connt:[],
        iFixe:false
      }
    },
    created () {
      this.$http.get('static/database/headerList.json').then((data) => {
        this.connt = data.body.connt
      })
    },
    mounted(){
      window.addEventListener('scroll',this.scroll)
    },
    methods:{
      scroll(){
        let top= window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
        this.iFixe = top>25?true:false;
      }
    },
    destroyed(){
      window.removeEventListener('scroll',this.scroll)
    }

  }
</script>

<style>
  #topNav{
    width: 100%;
    background: #000000;
  }
  #topNav a{
    color: #999;
    text-decoration: none;
  }
  #topNavWrap{
    width: 1090px;
    margin: 0 auto;
    height: 30px;
    line-height: 30px;
  }
  #topNavLeft{
    float: left;
    color: #999;
  }
  #topNavLeft .login{
    margin-left: 16px;
  }
  #topNavLeft .sep{
    padding: 0 10px;
  }
  #topNavLeft2{
    padding-left: 30px;
    float: left;
  }
  #topNavLeft a:hover,#topNavLeft2 a:hover{
    color: #FFFFFF;
  }
  #topNavRight{
    float: right;
    position: relative;
    right: -3px;
    margin: 0;
    padding: 0;
  }
  #topNavRight li{
    float: left;
    display: inline;
  }
  #topNavRight .mcDropMenu{
    display: none;
    position: absolute;
    border: 1px solid #e8e8ea;
    border-top: 0px;
    background: #FFFFFF;
    z-index: 101;
  }
  #topNavRight li>a:hover{
    color: #FFFFFF;
  }
  #topNavRight .mcDropMenu a{
    display: block;
    padding: 0 13px 0 13px;
    text-align:left;
    white-space:nowrap
  }
  #topNavRight .mcDropMenuBox a:hover{
    color: #FF1e32;
  }
  #topNavRight .toplevel {
    padding: 0 14px 0 14px;
  }
  #topNavRight li:hover .mcDropMenuBox{
    background-color: #fff;
  }
  #topNavRight li:hover .mcDropMenuBox .mcDropMenu{
    display: block;
  }
  #docHead,#docHeadWrap{
    position: relative;
    height: 100px;
  }
  #docHead.topTabBoxFixed{
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100px;
    z-index: 1001;
    background: #fff;
    border-bottom: 1px solid #ddd;
    box-shadow: 0 0 10px rgb(0 0 0 / 20%);
  }
  #docHeadWrap{
    width: 1090px;
    margin: 0 auto;
  }

  #docHeadWrap .logo_new{
    position: absolute;
    left: 0;
    top: 20px;
    width: 330px;
    height: 65px;
    background: url(../../assets/logo.png) no-repeat 0px;
  }
  .m-searchiptbox{
    position: absolute;
    left: 343px;
    top: 33px;
  }
  #topsearch{
    width: 510px;
    height: 40px;
    background-color:#FF2337;
    border-radius: 40px;
  }
  #topsearch .wrap{
    float: left;
    margin: 2px 2px;
    background-color: #FFFFFF;
    padding: 6px 39px 6px 30px;
    border-radius: 24px 0 0 24px;
  }
  #topSearchInput{
    width: 410px;
    height: 24px;
    line-height:24px;
    border: 0;
    outline:none;
  }
  input{
    box-sizing: border-box;
  }
  .w-icon{
    background: url(../../assets/icon.png);
  }
  .w-icon-Sc1{
    position: absolute;
    left: 10px;
    top: 13px;
    width: 14px;
    height: 14px;
    background-position: -466px -667px;

  }
  #topSearchBtn{.
    display: inline-block;
    height: 40px;
    width: 50px;
    font-size: 19px;
    line-height: 40px;
    text-align: center;
    cursor: pointer;
    position: absolute;
    top: 0;
    right: 5px;
    background-position: -489px -655px;
  }
  .topsearchboxBackGround{
    width: 60px;
    height: 40px;
    background: #ff2337;
    border-radius: 40px;
    position: absolute;
    top: 0;
    right: 0;
  }
  .m-shopcartnew{
    display: block;
      position: absolute;
      right: 76px;
      top: 33px;
      width: 106px;
      height: 36px;
      background-color: #fff;
      line-height: 36px;
      font-size: 14px;
      text-align: center;
      -moz-border-radius: 36px;
      -webkit-border-radius: 36px;
      border-radius: 36px;
      border: 2px solid #ff1e32;
      text-decoration:none;
  }
  .m-shopcartnew .shop-cart-icon{
    display: inline-block;
        width: 20px;
        height: 20px;
        margin-right: 2px;
        margin-bottom: -5px;
        background:url(../../assets/shop.png) no-repeat 0px;
  }
  .m-shopcartnew .wrap{
      display: inline-block;
        padding-left: 6px;
        background: none;
        vertical-align: middle;
  }
</style>
