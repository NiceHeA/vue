<template>
  <div id="footer">
    <div class="footbg">
      <div class="box1">
        <div class="bg">
          <img src="../../assets/footbg1.png" >
        </div>
      </div>
      <div class="box2">
        <div class="bg">
          <img src="../../assets/footbg2.png" alt="">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
 export default {}
</script>

<style>
 #footer{
   width: 100%;
 }
 #footer .box1{
   width: 100%;
   height: 411px;
   background:#FFFFFF;
 }
 #footer .box2{
   width: 100%;
   height: 160px;
   background: #333;
 }
#footer .bg{
  width: 1100px;
  margin: 0 auto;
}
</style>
