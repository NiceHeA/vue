<template>
  <div id="banner-box">
    <div class="imgBox">
      <div class="sliderBox2">
        <img src="//kaola-haitao.oss.kaolacdn.com/63d1cc4c-b46a-41ad-b4a5-11aaf5a52e0aT2201061458_1920_506.jpg?x-oss-process=image/resize,w_1920/quality,q_90" >
      </div>
    </div>
    <div class="m-sellpoint">
      <div class="m-contentwrap">
        <div class="sellpoint">
          <a href="" class="itm">
           <i>
            <img src="../../assets/icon1.png" >
           </i>
            <span>考拉自营</span>
          </a>
          <a href="" class="itm">
            <i>
              <img src="../../assets/icon2.png" >
            </i>
            <span>全球直采</span>
          </a>
          <a href="" class="itm">
            <i>
              <img src="../../assets/icon3.png" >
            </i>
            <span>假一赔十</span>
          </a>
          <a href="" class="itm">
            <i>
              <img src="../../assets/icon4.png" >
            </i>
            <span>售后无忧</span>
          </a>
        </div>
      
      </div>
    </div>
  </div>
</template>

<script>
  export default {}
</script>

<style>
  .imgBox{
    position: relative;
    width: 100%;
    overflow: hidden;
  }
  .m-sellpoint{
    position: relative;
    margin-top: -45px;
    margin-bottom: 20px;
    height: 45px;
    background-color: rgba(0,0,0,.3);
  }
  .m-sellpoint .m-contentwrap{
    margin: 0 auto;
    width: 1090px;
  }
  .m-sellpoint .m-contentwrap .sellpoint{
    float: left;
    height: 44px;
    line-height: 44px;
    font-size: 12px;
    color: #fff;
  }
  .m-sellpoint .m-contentwrap .sellpoint i{
    padding-top: 5px;
    float: left;
  }
  .m-sellpoint .m-contentwrap .sellpoint .itm{
    float: left;
    margin-right: 40px;
    color: #fff;
    text-decoration: none;
  }
  .m-sellpoint .m-contentwrap .download{
    float: right;
    line-height: 44px;
  }
  .m-sellpoint .m-contentwrap .download a{
    color: #FFFFFF;
  }
  .m-sellpoint .m-contentwrap .download i img{
    margin-top: 5px;
    float: left;
  }
</style>
