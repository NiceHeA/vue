<template>
  <div>
   <div class="party m-prolist">
      <h3 class="title">最新热卖
        <span class="img_pagebox" >
          <a href="" class="idxicon" v-for="(p,index) in party" :class="{'active':index==num}" @mousemove="mose(index)"></a>
        </span>
      </h3>
      <div class="prolist">
        <div class="itemgroup"  v-for="(d,i) in party" :style="{'display':+(i==num)?'block':'none'}">
          <div class="itemsale clearfix" v-for="s in d" >
            <a href="" class="pic" >
              <img v-bind:src="s.title">
            <h3 class="tit">{{s.imgsrc}}</h3>
             <p class="curprice">
               <span>￥</span>
               <strong>{{s.priceA}}</strong>
                <del class="item2">{{s.priceB}}</del>
             </p>
             </a>
          </div>
        </div>

      </div>

    </div>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        num:0,
        ctime:''
      }
    },
    name:'slide',
    props:{
      party:Array
    },
    created(){
    },
    methods:{
      autoPay(){
        this.num++;
        if(this.num==3){
          this.num = 0
        }
      },
      mose(s){
        this.num=s;
      },
      setTime(){
        this.ctime=setInterval(() => this.autoPay(),3000)
      },
      clearTimeSet(){
        clearInterval(this.ctime);
      }
    },
    mounted() {
      this.setTime();
    },
    beforeDestroy() {
      this.clearTimeSet();
    }
  }
</script>

<style>
  .m-productfloor .party{
    width: 219px;
    border: 1px solid #e9e9e9;
    border-width: 0 1px 1px 0;
    border-left: 0;
    float: right;
  }
  .m-prolist .prolist{
    position: relative;
    width: 100%;
    height: 480px;
    overflow: hidden;
  }
  .m-prolist .prolist .itemgroup{
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
  }
  .m-prolist .title{
    font-size: 16px;
    line-height: 58px;
    padding: 0 0 0 10px;
    color: #333;
    font-weight: 700;
    height: 58px;
    border: 1px solid #e9e9e9;
    border-left-width: 0;
    position: relative;
    text-align: left;
    border-right: 0;
  }
  .m-prolist .img_pagebox .idxicon{
    display: inline-block;
    margin: 0 2px;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    overflow: hidden;
    vertical-align: middle;
    line-height: 0;
    font-size: 0;
    text-decoration: none;
    cursor: pointer;
    background: #e1e1e1;
  }
  .m-prolist .img_pagebox .active{
    background-color: #333;
  }
  .m-prolist .img_pagebox{
    position: absolute;
    top: 0;
    right: 9px;
  }
  .m-prolist .itemsale{
    border-bottom: 1px dotted #e9e9e9;
    padding: 27px 9px 0 5px;
    height: 93px;
  }
  .m-prolist .itemsale .tit{
    line-height: 18px;
    height: 36px;
    overflow: hidden;
    color: #666;
    font-size: 100% ;
    font-weight:400;
    padding-left: 5px;
  }
  .m-prolist .itemsale .pic,.m-prolist .itemsale .pic img,.m-prolist .itemsale .curprice{
    float: left;
  }
  .m-prolist .itemsale .curprice{
    font-size: 18px;
    color: #ff1e32;
    margin: 6px 0 0 3px;
  }
  .m-prolist .itemsale .curprice strong{
    font-size: 20px;
    font-weight: 700;
    margin-left:-7px;
  }
  .m-prolist .itemsale .curprice .item2{
    color: #999;
    margin: 0 0 0 8px;
    font-size: 14px;
  }
</style>
