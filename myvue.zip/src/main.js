// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
// import Aglobal from './assets/js/global.js'
import store from './store/store.js'


// Vue.prototype.Aglobal=Aglobal;
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})

// var asd=document.querySelectorAll('.w-secondlist li a');
//   var sdsd=[];
//   for(var i=0;i<asd.length;i++)
//   {
//       var obj={
//         id:"",
//         title:"",
//         address:""
//       };
//       obj.title=asd[i].innerText
//      sdsd.push(obj);
//   }
    // var jsondata = {
    //     lsit:[],
    //     domO:document.querySelectorAll('#topCats li'),
    //     lst :function(arr){

    //         for(var i=0;i<arr.length;i++){
    //           var lt={};
    //           lt.ctgImg1=arr[i].children[0].currentSrc;
    //           lt.ctgImg2=arr[i].children[1].currentSrc;
    //           lt.ctgName=arr[i].children[2].innerText;
    //           lt.ctgTab=[];
    //           this.lsit.push(lt)
    //           this.tablist(arr[i].children,"item",i);
    //         }
    //     },
    //     tablist:function(arr,name,ix){
    //      for(var s = 0; s<arr.length;s++){
    //       if(arr[s].children.length>0&&arr[s].className!=name){
    //         this.tablist(arr[s].children,name,ix);
    //       }else if(arr[s].className==name){
    //           var bbb={
    //                 tabName:arr[s].children[0].innerText,
    //                 ctglist:[]
    //               };
    //           for(var i=0;i<arr[s].children[1].children.length;i++){
    //               bbb.ctglist.push(arr[s].children[1].children[i].innerText)
    //               alert(bbb.tabName);
    //           }
    //           this.lsit[ix].ctgTab.push(bbb);
    //       }
    //      }
    //     }
    // };
    //   jsondata.lst(jsondata.domO);
