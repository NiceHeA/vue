//  export default{
//     sta:false,
//     userName:'',
//      getCooki(cname){
//         var name = cname+"=";
//         var s =document.cookie.split(";");
//         for(var i=0;i<s.length;i++){
//            var ca=s[i].trim();
//            if(ca.indexOf(name)==0) return ca.substring(name.length,ca.length)
//         }
//     },
//      setCooki(v){
       
//         var Days = 30;
//         var exp=new Date();
//         exp.setTime(exp.getTime() + Days*24*60*60*1000);
//         this.sta=true;
//         document.cookie="username="+v+";expires="+exp.toGMTString();
//     }
//  } 