import Vue from 'vue'
import Router from 'vue-router'
import VueRource from 'vue-resource'
import Home from '@/pages/Home'
import haigou from '@/pages/haigou'
import login from '@/pages/login'
import prductInfo from '@/pages/prductInfo'
Vue.use(Router)
Vue.use(VueRource)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/haigou',
      name: 'haigou',
      component: haigou
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/prductInfo',
      name: 'prductInfo',
      component: prductInfo
    }
  ]
})
