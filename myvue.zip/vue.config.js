module.exports={
    assetsDir:'static',
    parallel:false,
    publicPath:'./'
}